export interface Pizza{
    key:string;
    title:string;
    price:number;
    category:string;
    imageUrl:string;

}