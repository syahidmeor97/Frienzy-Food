export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyCp4qU15edPezejVKr9yx4OEttr6njtlGA",
    authDomain: "pizzaholic-fb263.firebaseapp.com",
    databaseURL: "https://pizzaholic-fb263.firebaseio.com",
    projectId: "pizzaholic-fb263",
    storageBucket: "",
    messagingSenderId: "381791354835",
    appId: "1:381791354835:web:8cf58750964aa287"
  }
};
